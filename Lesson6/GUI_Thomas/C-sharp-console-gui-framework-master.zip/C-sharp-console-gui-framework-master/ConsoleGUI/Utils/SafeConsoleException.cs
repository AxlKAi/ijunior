﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleGUI.Utils
{
	internal sealed class SafeConsoleException : Exception
	{ }
}
