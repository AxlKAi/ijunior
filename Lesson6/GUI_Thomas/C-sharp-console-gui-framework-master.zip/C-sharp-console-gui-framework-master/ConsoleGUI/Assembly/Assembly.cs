﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("ConsoleGUI.Test")]
[assembly: InternalsVisibleTo("DynamicProxyGenAssembly2")]
