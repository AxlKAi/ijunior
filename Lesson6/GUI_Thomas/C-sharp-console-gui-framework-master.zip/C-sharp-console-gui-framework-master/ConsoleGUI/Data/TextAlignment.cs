﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleGUI.Data
{
	public enum TextAlignment
	{
		Left,
		Center,
		Right
	}
}
